package client;

import client.gui.ClientChatForm;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SocketHandlerClientSide implements Runnable {
    private Socket socket;
    private DataInputStream dis;
    private DataOutputStream dos;
    private ClientChatForm guiContainer;
    private String myName;
    private Thread listener;
    private boolean isRunning = false;
    
    public SocketHandlerClientSide(ClientChatForm container) {
        guiContainer = container;
    }
    
    public void connect(String addr, int port, String name) throws Exception {
        myName = name;
        
        // Kết nối đến server
        InetAddress ip = InetAddress.getByName(addr);
        System.out.println("Đang kết nối tới " + ip + ":" + port + "...");
        guiContainer.setLoadingState(true, "Đang kết nối...");
        
        socket = new Socket(ip, port);
        dis = new DataInputStream(socket.getInputStream());
        dos = new DataOutputStream(socket.getOutputStream());
        
        // Gửi lệnh tham gia
        dos.writeUTF("CMD_JOIN " + myName);
        
        // Khởi động luồng lắng nghe
        isRunning = true;
        listener = new Thread(this);
        listener.start();
        
        System.out.println("Đã kết nối tới server với tên " + myName);
    }
    
    @Override
    public void run() {
        while (isRunning) {
            try {
                String received = dis.readUTF();
                processMessage(received);
            } catch (IOException e) {
                Logger.getLogger(SimpleChatClientHandler.class.getName()).log(Level.SEVERE, null, e);
                isRunning = false;
                guiContainer.setLoadingState(true, "Mất kết nối với máy chủ");
            }
        }
        
        close();
    }
    
    private void processMessage(String message) {
        System.out.println("Nhận được: " + message);
        
        String[] parts = message.split(" ", 2);
        String command = parts[0];
        
        switch (command) {
            case "CMD_ONLINE":
                // Định dạng: CMD_ONLINE name1 name2 name3...
                String[] names = message.substring(11).trim().split(" ");
                ArrayList<String> onlineList = new ArrayList<>(Arrays.asList(names));
                guiContainer.updateOnlineList(onlineList);
                guiContainer.setLoadingState(false, "");
                break;
                
            case "CMD_MESSAGE":
                // Định dạng: CMD_MESSAGE sender:message
                if (parts.length > 1) {
                    String[] msgParts = parts[1].split(":", 2);
                    if (msgParts.length == 2) {
                        String sender = msgParts[0];
                        String content = msgParts[1];
                        guiContainer.addChat(sender, sender, content);
                    }
                }
                break;
                
            case "CMD_FILE_XD":
                // Định dạng: CMD_FILE_XD sender receiver filename
                // Xử lý thông báo chuyển file
                break;
        }
    }
    
    public void sendChatMessage(String receiver, String content) {
        try {
            dos.writeUTF("CMD_CHAT " + myName + " " + receiver + " " + content);
            // Thêm vào lịch sử chat của chính mình
            guiContainer.addChat(receiver, myName, content);
        } catch (IOException e) {
            Logger.getLogger(SimpleChatClientHandler.class.getName()).log(Level.SEVERE, null, e);
        }
    }
    
    public void sendChatToAll(String content) {
        try {
            dos.writeUTF("CMD_CHATALL " + myName + " " + content);
        } catch (IOException e) {
            Logger.getLogger(SimpleChatClientHandler.class.getName()).log(Level.SEVERE, null, e);
        }
    }
    
    public void close() {
        try {
            isRunning = false;
            if (dis != null) dis.close();
            if (dos != null) dos.close();
            if (socket != null) socket.close();
        } catch (IOException e) {
            Logger.getLogger(SimpleChatClientHandler.class.getName()).log(Level.SEVERE, null, e);
        }
    }
    
    public String getName() {
        return myName;
    }
}