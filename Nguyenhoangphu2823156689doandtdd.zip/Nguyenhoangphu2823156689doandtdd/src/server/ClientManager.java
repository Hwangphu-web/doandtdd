/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.util.ArrayList;

/**
 *
 * 
 */
public class ClientManager {

    ArrayList<SocketHandlerServerSide> clients;

    public ClientManager() {
        clients = new ArrayList<>();
    }

    public ArrayList<String> getOnlineName() {
        ArrayList<String> ret = new ArrayList<>();
        clients.forEach((c) -> {
            if (c.clientName != null) {
                ret.add(c.clientName);
            }
        });
        return ret;
    }

    public boolean add(SocketHandlerServerSide c) {
        if (!clients.contains(c)) {
            clients.add(c);
            return true;
        }
        return true;
    }

    public boolean remove(SocketHandlerServerSide c) {
        if (clients.contains(c)) {
            clients.remove(c);
            return true;
        }
        return false;
    }

    public SocketHandlerServerSide find(String name) {
        for (SocketHandlerServerSide c : clients) {
            if (c.clientName.equals(name)) {
                return c;
            }
        }
        return null;
    }

    public void broadcast(String msg) {
        clients.forEach((c) -> {
            c.sendData(msg);
        });
    }

    public int getSize() {
        return clients.size();
    }
}
