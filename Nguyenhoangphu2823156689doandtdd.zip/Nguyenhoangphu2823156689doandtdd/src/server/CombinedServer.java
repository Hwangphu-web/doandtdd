package server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Vector;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JOptionPane;
import javax.swing.JPanel;  // Make sure this import is included
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Color;
import java.awt.Dimension;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.StringTokenizer;

public class CombinedServer extends JFrame {
    // UI Components
    private JTextArea logArea;
    private JTextField portField;
    private JButton startButton;
    private JButton stopButton;
    private SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss a");
    
    // Server Components
    private ServerSocket serverSocket;
    private boolean isRunning = false;
    private Thread serverThread;
    private ThreadPoolExecutor executor;
    
    // Client Management
    private ArrayList<ClientHandler> secureClients = new ArrayList<>();
    private Vector<Socket> chatSockets = new Vector<>();
    private Vector<String> chatClientNames = new Vector<>();
    private Vector<String> fileSharingUsernames = new Vector<>();
    private Vector<Socket> fileSharingSockets = new Vector<>();
    
    // Buffer size for file transfer
    private final int BUFFER_SIZE = 8192;
    
    public CombinedServer() {
        setTitle("Combined Server - Chat & File Sharing");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        initComponents();
        setLocationRelativeTo(null);
    }
    
    private void initComponents() {
        // Main panel
        setLayout(new BorderLayout(10, 10));
        
        // Log area
        logArea = new JTextArea();
        logArea.setEditable(false);
        logArea.setBackground(Color.BLACK);
        logArea.setForeground(Color.WHITE);
        logArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scrollPane = new JScrollPane(logArea);
        add(scrollPane, BorderLayout.CENTER);
        
        // Control panel
        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        
        JLabel portLabel = new JLabel("Port:");
        portField = new JTextField("5056", 6);
        startButton = new JButton("Start Server");
        stopButton = new JButton("Stop Server");
        stopButton.setEnabled(false);
        
        controlPanel.add(portLabel);
        controlPanel.add(portField);
        controlPanel.add(startButton);
        controlPanel.add(stopButton);
        
        add(controlPanel, BorderLayout.SOUTH);
        
        // Event listeners
        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                startServer();
            }
        });
        
        stopButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                stopServer();
            }
        });
    }
    
    private void startServer() {
        try {
            int port = Integer.parseInt(portField.getText().trim());
            
            // Create server socket
            serverSocket = new ServerSocket(port);
            isRunning = true;
            
            // Create thread pool
            executor = new ThreadPoolExecutor(
                10,                // Core pool size
                100,               // Maximum pool size
                10,                // Thread timeout
                TimeUnit.SECONDS,
                new ArrayBlockingQueue<>(8)  // Queue capacity
            );
            
            // Start the server thread
            serverThread = new Thread(new Runnable() {
                @Override
                public void run() {
                    appendMessage("Server started on port " + port);
                    
                    // Start online list broadcast thread
                    new Thread(new OnlineListBroadcaster()).start();
                    
                    // Accept connections
                    while (isRunning) {
                        try {
                            Socket clientSocket = serverSocket.accept();
                            appendMessage("New client connected: " + clientSocket.getInetAddress());
                            
                            // Create and start client handler
                            ClientHandler handler = new ClientHandler(clientSocket);
                            executor.execute(handler);
                        } catch (IOException e) {
                            if (isRunning) {
                                appendMessage("Error accepting client connection: " + e.getMessage());
                            }
                        }
                    }
                }
            });
            
            serverThread.start();
            
            // Update UI
            startButton.setEnabled(false);
            stopButton.setEnabled(true);
            portField.setEnabled(false);
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid port number", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (IOException e) {
            appendMessage("Error starting server: " + e.getMessage());
            JOptionPane.showMessageDialog(this, "Cannot start server: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void stopServer() {
        int confirm = JOptionPane.showConfirmDialog(this, 
                "Are you sure you want to stop the server?", 
                "Confirm", 
                JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                isRunning = false;
                
                // Close all client connections
                for (ClientHandler client : secureClients) {
                    client.close();
                }
                
                // Close server socket
                if (serverSocket != null && !serverSocket.isClosed()) {
                    serverSocket.close();
                }
                
                // Shutdown executor
                if (executor != null) {
                    executor.shutdownNow();
                }
                
                // Update UI
                startButton.setEnabled(true);
                stopButton.setEnabled(false);
                portField.setEnabled(true);
                
                appendMessage("Server stopped");
                
            } catch (IOException e) {
                appendMessage("Error stopping server: " + e.getMessage());
            }
        }
    }
    
    public void appendMessage(String message) {
        Date date = new Date();
        String timestamp = sdf.format(date);
        logArea.append(timestamp + ": " + message + "\n");
        logArea.setCaretPosition(logArea.getText().length());
    }
    
    // Method to broadcast online client list
    private void broadcastOnlineList() {
        StringBuilder msg = new StringBuilder("CMD_ONLINE");
        
        for (String clientName : chatClientNames) {
            msg.append(" ").append(clientName);
        }
        
        for (Socket socket : chatSockets) {
            try {
                DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
                dos.writeUTF(msg.toString());
            } catch (IOException e) {
                appendMessage("Error broadcasting online list: " + e.getMessage());
            }
        }
    }
    
    // Method to find a client socket by name
    private Socket getClientSocket(String clientName) {
        for (int i = 0; i < chatClientNames.size(); i++) {
            if (chatClientNames.elementAt(i).equals(clientName)) {
                return chatSockets.elementAt(i);
            }
        }
        return null;
    }
    
    // Method to find a file sharing socket by username
    private Socket getFileSharingSocket(String username) {
        for (int i = 0; i < fileSharingUsernames.size(); i++) {
            if (fileSharingUsernames.elementAt(i).equals(username)) {
                return fileSharingSockets.elementAt(i);
            }
        }
        return null;
    }
    
    // Method to remove a client from the list
    private void removeClient(String clientName) {
        for (int i = 0; i < chatClientNames.size(); i++) {
            if (chatClientNames.elementAt(i).equals(clientName)) {
                chatClientNames.removeElementAt(i);
                chatSockets.removeElementAt(i);
                appendMessage("Client removed: " + clientName);
                break;
            }
        }
    }
    
    // Method to remove a file sharing client
    private void removeFileSharingClient(String username) {
        for (int i = 0; i < fileSharingUsernames.size(); i++) {
            if (fileSharingUsernames.elementAt(i).equals(username)) {
                try {
                    Socket socket = fileSharingSockets.elementAt(i);
                    if (socket != null && !socket.isClosed()) {
                        socket.close();
                    }
                    fileSharingUsernames.removeElementAt(i);
                    fileSharingSockets.removeElementAt(i);
                    appendMessage("File sharing client removed: " + username);
                } catch (IOException e) {
                    appendMessage("Error removing file sharing client: " + e.getMessage());
                }
                break;
            }
        }
    }
    
    // Thread to broadcast online list periodically
    private class OnlineListBroadcaster implements Runnable {
        @Override
        public void run() {
            try {
                while (isRunning) {
                    broadcastOnlineList();
                    Thread.sleep(2000);
                }
            } catch (InterruptedException e) {
                appendMessage("Online list broadcaster interrupted: " + e.getMessage());
            }
        }
    }
    
    // Client handler class
    private class ClientHandler implements Runnable {
        private Socket socket;
        private DataInputStream dis;
        private DataOutputStream dos;
        private String clientName;
        private String fileSharingUsername;
        private boolean isRunning = true;
        
        public ClientHandler(Socket socket) {
            this.socket = socket;
            try {
                dis = new DataInputStream(socket.getInputStream());
                dos = new DataOutputStream(socket.getOutputStream());
            } catch (IOException e) {
                appendMessage("Error creating client handler: " + e.getMessage());
                isRunning = false;
            }
        }
        
        @Override
        public void run() {
            try {
                while (isRunning) {
                    String data = dis.readUTF();
                    processMessage(data);
                }
            } catch (IOException e) {
                appendMessage("Client disconnected: " + (clientName != null ? clientName : "unknown"));
            } finally {
                // Clean up
                if (clientName != null) {
                    removeClient(clientName);
                }
                if (fileSharingUsername != null) {
                    removeFileSharingClient(fileSharingUsername);
                }
                close();
                broadcastOnlineList();
            }
        }
        
        private void processMessage(String data) {
            StringTokenizer st = new StringTokenizer(data);
            String cmd = st.nextToken();
            
            switch (cmd) {
                case "CMD_JOIN":
                    // CMD_JOIN [clientUsername]
                    clientName = st.nextToken();
                    chatClientNames.add(clientName);
                    chatSockets.add(socket);
                    appendMessage("Client joined: " + clientName);
                    broadcastOnlineList();
                    break;
                    
                case "CMD_CHAT":
                    // CMD_CHAT [from] [sendTo] [message]
                    String from = st.nextToken();
                    String sendTo = st.nextToken();
                    StringBuilder msgBuilder = new StringBuilder();
                    while (st.hasMoreTokens()) {
                        msgBuilder.append(" ").append(st.nextToken());
                    }
                    String msg = msgBuilder.toString();
                    
                    Socket recipientSocket = getClientSocket(sendTo);
                    if (recipientSocket != null) {
                        try {
                            DataOutputStream recipientDos = new DataOutputStream(recipientSocket.getOutputStream());
                            recipientDos.writeUTF("CMD_MESSAGE " + from + ":" + msg);
                            appendMessage("Message from " + from + " to " + sendTo + ": " + msg);
                        } catch (IOException e) {
                            appendMessage("Error sending message to " + sendTo + ": " + e.getMessage());
                        }
                    } else {
                        appendMessage("Recipient not found: " + sendTo);
                    }
                    break;
                    
                case "CMD_CHATALL":
                    // CMD_CHATALL [from] [message]
                    String sender = st.nextToken();
                    StringBuilder allMsgBuilder = new StringBuilder();
                    while (st.hasMoreTokens()) {
                        allMsgBuilder.append(" ").append(st.nextToken());
                    }
                    String allMsg = allMsgBuilder.toString();
                    
                    for (int i = 0; i < chatSockets.size(); i++) {
                        if (!chatClientNames.elementAt(i).equals(sender)) {
                            try {
                                DataOutputStream chatDos = new DataOutputStream(chatSockets.elementAt(i).getOutputStream());
                                chatDos.writeUTF("CMD_MESSAGE " + sender + " " + allMsg);
                            } catch (IOException e) {
                                appendMessage("Error broadcasting message: " + e.getMessage());
                            }
                        }
                    }
                    appendMessage("Broadcast from " + sender + ": " + allMsg);
                    break;
                    
                case "CMD_SHARINGSOCKET":
                    // CMD_SHARINGSOCKET [username]
                    fileSharingUsername = st.nextToken();
                    fileSharingUsernames.add(fileSharingUsername);
                    fileSharingSockets.add(socket);
                    appendMessage("File sharing enabled for: " + fileSharingUsername);
                    break;
                    
                case "CMD_SENDFILE":
                    // CMD_SENDFILE [Filename] [Size] [Recipient] [Sender]
                    String fileName = st.nextToken();
                    String fileSize = st.nextToken();
                    String recipient = st.nextToken();
                    String fileSender = st.nextToken();  // Changed variable name to avoid conflict
                    
                    Socket recipientFileSocket = getFileSharingSocket(recipient);
                    if (recipientFileSocket != null) {
                        try {
                            DataOutputStream fileDos = new DataOutputStream(recipientFileSocket.getOutputStream());
                            fileDos.writeUTF("CMD_SENDFILE " + fileName + " " + fileSize + " " + fileSender);
                            
                            // Transfer file data
                            InputStream input = socket.getInputStream();
                            OutputStream output = recipientFileSocket.getOutputStream();
                            byte[] buffer = new byte[BUFFER_SIZE];
                            int bytesRead;
                            
                            while ((bytesRead = input.read(buffer)) > 0) {
                                output.write(buffer, 0, bytesRead);
                            }
                            
                            output.flush();
                            
                            // Clean up after file transfer
                            removeFileSharingClient(recipient);
                            removeFileSharingClient(fileSender);
                            
                            appendMessage("File transferred: " + fileName + " from " + fileSender + " to " + recipient);
                        } catch (IOException e) {
                            appendMessage("Error sending file: " + e.getMessage());
                        }
                    } else {
                        try {
                            dos.writeUTF("CMD_SENDFILEERROR Client '" + recipient + "' not found or not ready for file transfer");
                        } catch (IOException e) {
                            appendMessage("Error sending file error message: " + e.getMessage());
                        }
                    }
                    break;
                    
                case "CMD_SEND_FILE_XD":
                    // CMD_SEND_FILE_XD [sender] [receiver] [filename]
                    String xdSender = st.nextToken();
                    String xdReceiver = st.nextToken();
                    String xdFilename = st.nextToken();
                    
                    Socket receiverSocket = getClientSocket(xdReceiver);
                    if (receiverSocket != null) {
                        try {
                            DataOutputStream receiverDos = new DataOutputStream(receiverSocket.getOutputStream());
                            receiverDos.writeUTF("CMD_FILE_XD " + xdSender + " " + xdReceiver + " " + xdFilename);
                            appendMessage("File transfer request from " + xdSender + " to " + xdReceiver + ": " + xdFilename);
                        } catch (IOException e) {
                            appendMessage("Error sending file transfer request: " + e.getMessage());
                        }
                    } else {
                        try {
                            dos.writeUTF("CMD_SENDFILEERROR Client '" + xdReceiver + "' not found");
                        } catch (IOException e) {
                            appendMessage("Error sending file error message: " + e.getMessage());
                        }
                    }
                    break;
                    
                default:
                    appendMessage("Unknown command: " + cmd);
                    break;
            }
        }
        
        public void close() {
            try {
                isRunning = false;
                if (dis != null) dis.close();
                if (dos != null) dos.close();
                if (socket != null && !socket.isClosed()) socket.close();
            } catch (IOException e) {
                appendMessage("Error closing client handler: " + e.getMessage());
            }
        }
        
        public void sendData(String data) {
            try {
                dos.writeUTF(data);
            } catch (IOException e) {
                appendMessage("Error sending data to client: " + e.getMessage());
            }
        }
    }
    
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CombinedServer().setVisible(true);
            }
        });
    }
}