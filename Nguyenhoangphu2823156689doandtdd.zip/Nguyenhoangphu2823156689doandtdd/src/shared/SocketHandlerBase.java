/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shared;

import client.SocketHandlerClientSide;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import shared.tripleDES.TripleDES;

/**
 *
 * 
 */
public class SocketHandlerBase {

    protected Socket socket;
    protected DataInputStream dis;
    protected DataOutputStream dos;

    protected TripleDES tripleDES = null;

    public SocketHandlerBase() {
    }

    public SocketHandlerBase(Socket s) throws IOException {
        this.socket = s;

        // obtaining input and output streams 
        this.dis = new DataInputStream(s.getInputStream());
        this.dos = new DataOutputStream(s.getOutputStream());
    }

    protected String getReceivedType(String received) {
        return received.split(Constants.SEPARATE_MARKER)[0];
    }

    protected String decryptReceivedData(String received) throws IOException {
        if (tripleDES != null) {
            byte[] crypted = Helper.base64Decode(received);
            return new String(tripleDES.decrypt(crypted));
        }
        return received;
    }

    protected void closeResources() {
        try {
            // closing resources
            socket.close();
            dis.close();
            dos.close();
        } catch (IOException ex) {
            Logger.getLogger(SocketHandlerClientSide.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    // send data
    public void sendPureData(String data) {
        try {
            dos.writeUTF(data);

        } catch (IOException ex) {
            Logger.getLogger(SocketHandlerClientSide.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void sendData(String data) {
        try {
            byte[] encrypted = tripleDES.encrypt(data.getBytes());
            String strEncrypted = Helper.base64Encode(encrypted);
            dos.writeUTF(strEncrypted);

        } catch (IOException ex) {
            Logger.getLogger(SocketHandlerClientSide.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
