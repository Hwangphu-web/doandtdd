package shared;

public class Constants {
    public static final int SERVER_PORT = 5056;
    public static final String RSA_PRIVATEKEY_PATH = "src/server/rsa-key/privateKey";
    public static final String RSA_PUBLICKEY_PATH = "src/server/rsa-key/publicKey";

    public static final String SEPARATE_MARKER = ";";
    public static final String CLIENT_DATA_EVENT = "CLIENT_DATA_EVENT";
    public static final String CHAT_EVENT = "CHAT_EVENT";
    public static final String ONLINE_LIST_EVENT = "ONLINE_LIST_EVENT";
    public static final String FILE_EVENT = "FILE_EVENT"; // Thêm cho file
    public static final String KEYS_EVENT = "KEYS_EVENT"; // Thêm để gửi key TripleDES
}